// js/zotero-bar-chart.js

(async function renderZoteroBarChart() {
    const settings = window.zoteroBarChartSettings;
    if (!settings.library) return;

    const chartCtx = document.getElementById('zotero-bar-chart');
    if (!chartCtx) return;

    // Helper to fetch all items with pagination
    async function fetchAllZoteroItems(libraryKey) {
        const items = [];
        let start = 0;
        let batch;

        do {
            const url = `https://api.zotero.org/groups/${libraryKey}/items?include=data&limit=100&start=${start}`;
            const res = await fetch(url);
            batch = await res.json();
            if (Array.isArray(batch)) items.push(...batch);
            start += 100;
        } while (Array.isArray(batch) && batch.length === 100);

        return items;
    }

    // Fetch data and process
    const rawItems = await fetchAllZoteroItems(settings.library);
    const yearCounts = {};
    const now = new Date();
    const thisYear = now.getFullYear();
    const thisMonth = now.getMonth() + 1;

    for (const item of rawItems) {
        const date = item.data.date;
        if (!date) continue;

        const yearMatch = date.match(/\b(\d{4})\b/);
        if (!yearMatch) continue;

        const year = parseInt(yearMatch[1], 10);
        if (!year) continue;

        yearCounts[year] = (yearCounts[year] || 0) + 1;
    }

    const years = Object.keys(yearCounts).sort();
    const actualCounts = years.map(y => yearCounts[y]);

    const datasets = [{
        label: 'Citations per Year',
        data: actualCounts,
        backgroundColor: settings.color
    }];

    // Handle extrapolation for current year
    if (settings.extrapolate && yearCounts[thisYear]) {
        const actual = yearCounts[thisYear];
        const projected = Math.round((actual / thisMonth) * 12);

        const idx = years.indexOf(thisYear.toString());
        datasets[0].data[idx] = actual;
        datasets.push({
            label: 'Projected Full Year',
            data: years.map(y => y == thisYear ? projected : null),
            backgroundColor: settings.color + '88',
            borderWidth: 0
        });
    }

    new Chart(chartCtx, {
        type: 'bar',
        data: {
            labels: years,
            datasets
        },
        options: {
            responsive: true,
            plugins: {
                legend: { position: 'top' },
                title: { display: true, text: 'Zotero Citations by Year' }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    title: {
                        display: true,
                        text: 'Number of Citations'
                    }
                }
            }
        }
    });
})();